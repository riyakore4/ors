package com.example.course.controller;

import com.example.course.entity.Course;
import com.example.course.entity.Student;
import com.example.course.service.CourseService;
import com.example.course.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class CourseController {
    @Autowired
    private CourseService courseService;

    @Autowired
    private StudentService studentService;

    // Course endpoints
    @PostMapping("/courses")
    public Course addCourse(@RequestBody Course course) {
        return courseService.addCourse(course);
    }

    @GetMapping("/courses")
    public List<Course> getAllCourses() {
        return courseService.getAllCourses();
    }

    // Student endpoints
    @PostMapping("/students")
    public Student addStudent(@RequestBody Student student) {
        return studentService.addStudent(student);
    }

    @GetMapping("/students")
    public List<Student> getAllStudents() {
        return studentService.getAllStudents();
    }

    @PostMapping("/students/{studentId}/courses/{courseId}/enroll")
    public ResponseEntity<Void> enrollStudent(@PathVariable Long studentId, @PathVariable Long courseId) {
        courseService.enrollStudent(studentId, courseId);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/students/{studentId}/courses/{courseId}/unenroll")
    public ResponseEntity<Void> unenrollStudent(@PathVariable Long studentId, @PathVariable Long courseId) {
        courseService.unenrollStudent(studentId, courseId);
        return ResponseEntity.ok().build();
    }
}
